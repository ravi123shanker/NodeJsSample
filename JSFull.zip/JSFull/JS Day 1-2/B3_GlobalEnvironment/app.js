var a = 'Hello World!';

function b() {
    
}