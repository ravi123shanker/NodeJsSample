b();
console.log(a);

var a = 'Hello World!';

function b() {
    if(a==undefined){
    console.log('Called b!');

    }
}