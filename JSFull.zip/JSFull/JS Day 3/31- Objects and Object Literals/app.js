var Deepak = {
    firstname: 'Deepak',
    lastname: 'Jha',
    address: {
        street: '492B',
        city: 'Indirapuram',
        state: 'UP'
    }
};
console.log(Deepak);

function greet(person) {
    console.log('Hi ' + person.firstname);
}

greet(Deepak);

greet({
    firstname: 'Arya',
    lastname: 'Stark'
});

Deepak.address2 = {
    street: 'kormangala, bangalore.'
}
