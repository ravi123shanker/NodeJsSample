var greet = 'Hello!';
var greet = 'Namaste!';

console.log(greet);

var english = {
    greetings: {
        basic: 'Hello!'
    }
};

var hindi = {};

hindi.greet = 'Namaste!';

console.log(english);
console.log(hindi);
