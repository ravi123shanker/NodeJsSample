var a ={};
var b =[];
function c(){
}
