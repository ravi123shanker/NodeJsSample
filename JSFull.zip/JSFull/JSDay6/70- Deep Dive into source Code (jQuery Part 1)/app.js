var q = $("ul.people li");
console.log(q);