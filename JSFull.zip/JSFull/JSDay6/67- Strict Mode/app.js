var person;
persom = {};
console.log(persom);


function logNewPerson() {
    "use strict";

    var person2;
    persom2 = {};
    console.log(persom2);
}
logNewPerson();
