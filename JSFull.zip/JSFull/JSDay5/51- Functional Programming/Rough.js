var arr1[1,2,4];
console.log(arr1);



// Need an array double each value
var arr2=[];

for(var i=0;i<arr1.length;i++){
  arr2.push(arr2[i]*2);
}

console.log(arr2);
