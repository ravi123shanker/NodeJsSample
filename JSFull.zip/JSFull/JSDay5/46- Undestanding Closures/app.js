function greet(whattosay) {

   return function(name) {
       console.log(whattosay + ' ' + name);
   }

}

greet('Hi')('Deepak');


// var sayHi = greet('Hi');
// sayHi('Deepak');
