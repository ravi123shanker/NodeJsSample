function greet(firstname, lastname, language) {
    console.log(arguments);
    language = language || 'en';

    if (arguments.length === 0) {
        console.log('Missing parameters!');
        console.log('-------------');
        console.log(firstname);
        console.log(lastname);
        console.log(language);
        return;
    }


    console.log('-------------');
    console.log('arg 0: ' + arguments[0]);


}

greet();
// greet('John');
// greet('John', 'Doe');
// greet('John', 'Doe', 'es');

// in ES6 I can do:  function greet(firstname, ...other)
// and 'other' will be an array that contains the rest of the arguments
