function getPerson() {

    return {
        firstname: 'Deepak'
    }

}

console.log(getPerson());
