// IIFE
var greeting = 'Hello';

(function( name) {

    // global.greeting = 'Hello';
    console.log(greeting + ' ' + name);

}( 'John')); // IIFE
