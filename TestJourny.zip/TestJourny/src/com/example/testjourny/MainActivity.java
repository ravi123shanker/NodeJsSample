package com.example.testjourny;

import com.crashlytics.android.Crashlytics;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Date;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.SoundPool;
import android.media.SoundPool.OnLoadCompleteListener;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	public static double totalKm = 0.0f;
	public static double speed = 0.0f;
	public static double maxSpeed = 0.0f;
	public static double avgSpeed = 0.0f;
	public static double fare = 0.0f;
	public static Location jornyStartLocation = null;
	public static Location prevLocation=null;
	public static SharedPreferences sharedPref=null;
	public static boolean soundPlayed=false;
	public static double sumSpeed=0.0f;
	public static long countSpeed=0;

	LocationManager locManager;
	Handler handler;
	Button btnStart, btnEnd, btnSnooze;
	TextView textKm, textSpeed, textFare, textMaxSpeed, textAvgSpeed;

	public static SoundPool soundPool=null;
	public static int soundID;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Crashlytics.start(this);
		setContentView(R.layout.activity_main);
		locManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		btnStart = (Button) findViewById(R.id.btnStartJourny);
		btnEnd = (Button) findViewById(R.id.btnEndJourny);
		btnSnooze=(Button) findViewById(R.id.btnSnoozeAlarm);
		textKm = (TextView) findViewById(R.id.textviewKm);
		textSpeed = (TextView) findViewById(R.id.textviewSpeed);
		textMaxSpeed=(TextView) findViewById(R.id.textviewMaxSpeed);
		textAvgSpeed=(TextView) findViewById(R.id.textviewAvgSpeed);
		textFare = (TextView) findViewById(R.id.textviewFare);
		
		sharedPref=getSharedPreferences("journey_pref", MODE_PRIVATE);
		
		if (sharedPref.getString("journey_status", "").equals("start")) {
			btnStart.setEnabled(false);
			btnEnd.setEnabled(true);
			if(getPrevLocation()==null){
				setKm(sharedPref.getFloat("last_km", 0.0f));
				setFare(sharedPref.getFloat("last_fare", 0.0f));
				setMaxSpeed(sharedPref.getFloat("max_speed", 0.0f));
				countSpeed=sharedPref.getLong("count_speed", 0);
				setAvgSpeed((sharedPref.getFloat("sum_speed", 0.0f))/countSpeed);
				setSpeedSum(sharedPref.getFloat("sum_speed", 0.0f));
				
				Location lastLocation=new Location(sharedPref.getString("provider", "gps"));
				lastLocation.setLatitude(sharedPref.getFloat("last_lat", 0.0f));
				lastLocation.setLongitude(sharedPref.getFloat("last_lng", 0.0f));
				lastLocation.setSpeed(sharedPref.getFloat("last_speed", 0.0f));
				lastLocation.setTime(sharedPref.getLong("last_time", System.currentTimeMillis()));
				
				setPrevLocation(lastLocation);
				setJournyStartLocation(lastLocation);
				
				textKm.setText("Km Travelled: "
						+ String.format("%.3f", getKm()));
				textSpeed.setText("Current Speed (km/h): "
						+ String.format("%.2f", getSpeed()));
				textMaxSpeed.setText("Max Speed (km/h): "+ String.format("%.2f", getMaxSpeed()));
				textAvgSpeed.setText("Avg. Speed (km/h): "+ String.format("%.2f", getAvgSpeed()));
				textFare.setText("Total Fare(Rs.): "
						+ String.format("%.2f", getFare()));
				
				locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
						2000, 0, myLocationListener);
				locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0, myLocationListener);
			}
		} else {
			btnStart.setEnabled(true);
			btnEnd.setEnabled(false);
		}
		if(soundPlayed==true){
			btnSnooze.setVisibility(View.VISIBLE);
		}
		btnStart.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				btnStart.setEnabled(false);
				btnEnd.setEnabled(true);
				
				SharedPreferences.Editor editor=sharedPref.edit();
				editor.putString("journey_status", "start");
				editor.commit();
				
				countSpeed=0;
				
				textKm.setText("Km Travelled: 0.0");
				textSpeed.setText("Current Speed (km/h): 0.0");
				textMaxSpeed.setText("Max Speed (km/h): 0.0");
				textAvgSpeed.setText("Avg. Speed (km/h): 0.0");
				textFare.setText("Total Fare(Rs.): 0.0");
				
				locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
						2000, 0, myLocationListener);
				locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 0, myLocationListener);
			}
		});
		btnEnd.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				btnStart.setEnabled(true);
				btnEnd.setEnabled(false);
				
				SharedPreferences.Editor editor=sharedPref.edit();
				editor.clear();
				editor.commit();
				
				setKm(0.0f);
				setSpeed(0.0f);
				setAvgSpeed(0.0f);
				setMaxSpeed(0.0f);
				setSpeedSum(0.0f);
				setFare(0.0f);
				setPrevLocation(null);
				setJournyStartLocation(null);
				locManager.removeUpdates(myLocationListener);
				
				if(soundPool!=null){
					soundPool.release();
				}
				soundPlayed=false;
				if(btnSnooze.getVisibility()==0){
					btnSnooze.setVisibility(View.INVISIBLE);
				}
			}
		});
		btnSnooze.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(soundPool!=null){
					soundPool.release();
				}
				btnSnooze.setVisibility(View.INVISIBLE);
				soundPlayed=false;
			}
		});
		handler = new Handler(new Callback() {

			@Override
			public boolean handleMessage(Message msg) {
				// TODO Auto-generated method stub
				
				textKm.setText("Km Travelled: "
						+ String.format("%.3f", getKm()));
				textSpeed.setText("Current Speed (km/h): "
						+ String.format("%.2f", getSpeed()));
				textMaxSpeed.setText("Max Speed (km/h): "+ String.format("%.2f", getMaxSpeed()));
				textAvgSpeed.setText("Avg. Speed (km/h): "+ String.format("%.2f", getAvgSpeed()));
				textFare.setText("Total Fare(Rs.): "
						+ String.format("%.2f", getFare()));
				if(getSpeed() >= 80.0){
					if(btnSnooze.getVisibility()!=0){
						btnSnooze.setVisibility(View.VISIBLE);
					}
					
					playSound();
				}
				return false;
			}
		});
	}

	LocationListener myLocationListener = new LocationListener() {

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onLocationChanged(Location location) {
			// TODO Auto-generated method stub
			Log.e("Location updated", "Latitude: " + location.getLatitude()
					+ " Longitude: " + location.getLongitude() + " Provider: "
					+ location.getProvider() + " Speed: " + location.getSpeed()+" Accuracy: "+location.getAccuracy());
			long lastLogTime=sharedPref.getLong("last_log", 0);
			if(location.getTime()-lastLogTime >= 1000*60){
				// log print
				String msg="Latitude: " + location.getLatitude()
						+ " Longitude: " + location.getLongitude() + " Provider: "
						+ location.getProvider() + " Speed: " + location.getSpeed()+" Accuracy: "+location.getAccuracy();
				System.out.println("Inside print");
				logPrint(msg);
				SharedPreferences.Editor editor=sharedPref.edit();
				editor.putLong("last_log", location.getTime());
				editor.commit();
			}
			
			if(location.getProvider().equalsIgnoreCase("gps")){
				if (location.getAccuracy() <= 50.0 && location.hasSpeed()) {
					
					if (getPrevLocation() == null) {
						setPrevLocation(location);
						setJournyStartLocation(location);
					} else {
						if((location.getTime()- getPrevLocation().getTime()) >= 2000){
							
							double currentKm =getKm() + (location
									.distanceTo(getJournyStartLocation()) / 1000);
							double fareTotal = 0.0f;
							if (currentKm >= 0 && currentKm <= 10) {
								fareTotal = 50.0f;
							} else if(currentKm > 10){
								fareTotal = 50.0 + ((currentKm-10)*10);
							}
							double speedKmPerHour=location.getSpeed()*18/5;
							setSpeedSum(getSpeedSum()+speedKmPerHour);
							countSpeed++;
							
							SharedPreferences.Editor editor=sharedPref.edit();
							editor.putFloat("last_lat", (float)location.getLatitude());
							editor.putFloat("last_lng", (float)location.getLongitude());
							editor.putFloat("last_km", (float)currentKm);
							editor.putFloat("last_fare", (float) fareTotal);
							editor.putFloat("last_speed", location.getSpeed());
							editor.putLong("last_time", location.getTime());
							editor.putString("provider", location.getProvider());
							editor.putFloat("sum_speed", (float)getSpeedSum());
							editor.putLong("count_speed", countSpeed);
							if(getMaxSpeed() <= speedKmPerHour){
								editor.putFloat("max_speed", (float)speedKmPerHour);
							}
							editor.commit();
							
							setKm(currentKm);
							setSpeed(speedKmPerHour);
							if(getMaxSpeed() <= speedKmPerHour){
								setMaxSpeed(speedKmPerHour);
							}
							setAvgSpeed(getSpeedSum()/countSpeed);
							setFare(fareTotal);
							
							setPrevLocation(location);
							setJournyStartLocation(location);
							System.out.println("update UI");
							handler.sendEmptyMessage(0);
						}else{
							System.out.println("Invalid GPS data");
						}
						
					}
				}
			}else{
				sharedPref=getSharedPreferences("journey_pref", MODE_PRIVATE);
				long backGpsDataTime=sharedPref.getLong("last_time", 0);
				long timeDiff=location.getTime()-backGpsDataTime;
				if((timeDiff >= (1000*60*2) && timeDiff <= (1000*60*5)) || backGpsDataTime==0){
					if (location.getAccuracy() <= 210.0 && location.getSpeed() >= 0.0) {
						if (getPrevLocation() == null) {
							setPrevLocation(location);
							setJournyStartLocation(location);
						} else {
							if((location.getTime()- getPrevLocation().getTime()) >= 2000){
								
								double currentKm =getKm() + (location
										.distanceTo(getJournyStartLocation()) / 1000);
								double fareTotal = 0.0f;
								if (currentKm >= 0 && currentKm <= 10) {
									fareTotal = 50.0f;
								} else if(currentKm > 10){
									fareTotal = 50.0 + ((currentKm-10)*10);
								}
								double speedKmPerHour=location.getSpeed()*18/5;
								setSpeedSum(getSpeedSum()+speedKmPerHour);
								countSpeed++;
								
								SharedPreferences.Editor editor=sharedPref.edit();
								editor.putFloat("last_lat", (float)location.getLatitude());
								editor.putFloat("last_lng", (float)location.getLongitude());
								editor.putFloat("last_km", (float)currentKm);
								editor.putFloat("last_fare", (float) fareTotal);
								editor.putFloat("last_speed", location.getSpeed());
								editor.putLong("last_time", location.getTime());
								editor.putString("provider", location.getProvider());
								editor.putFloat("sum_speed", (float)getSpeedSum());
								editor.putLong("count_speed", countSpeed);
								if(getMaxSpeed() <= speedKmPerHour){
									editor.putFloat("max_speed", (float)speedKmPerHour);
								}
								editor.commit();
								
								setKm(currentKm);
								setSpeed(speedKmPerHour);
								if(getMaxSpeed() <= speedKmPerHour){
									setMaxSpeed(speedKmPerHour);
								}
								setAvgSpeed(getSpeedSum()/countSpeed);
								setFare(fareTotal);
								
								setPrevLocation(location);
								setJournyStartLocation(location);
								
								handler.sendEmptyMessage(0);
							}else{
								System.out.println("Invalid GPS data");
							}
							
						}
					}else{
						System.out.println("Inaccurate data high accuracy: "+location.getAccuracy());
					}
				
				}
			}
			

		}
	};

	@SuppressLint("SdCardPath")
	public static void logPrint(String str) {
		// TODO Auto-generated method stub
		try {
			File myFile=null;
			Boolean isSDPresent = android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);
			if(isSDPresent){
				myFile = new File("/sdcard/journey.txt");
			}else{
				myFile=new File(Environment.getDataDirectory()+"/journey.txt");
			}
			
			if (!myFile.exists()) {
				myFile.createNewFile();
			}
			
			FileInputStream fin = new FileInputStream(myFile);
			BufferedReader brReader = new BufferedReader(new InputStreamReader(
					fin));
			String aDataRow = "";
			String aBuffer = "";
			while ((aDataRow = brReader.readLine()) != null) {
				aBuffer += aDataRow + "\n";
			}

			FileOutputStream fOut = new FileOutputStream(myFile);
			OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
			Date writeDate = new Date(System.currentTimeMillis());
			myOutWriter.append(aBuffer + "\nDate: " + writeDate
					+ "\n Message: \n" + str);
			brReader.close();
			fin.close();
			myOutWriter.close();
			fOut.close();
		} catch (Exception e11) {
			System.out.println("Error " + e11.toString());
			e11.printStackTrace();
		}
	}
	public void setKm(double totalKm) {
		this.totalKm = totalKm;
	}

	public double getKm() {
		return totalKm;
	}

	public void setMaxSpeed(double maxSpeed){
		this.maxSpeed=maxSpeed;
	}
	
	public double getMaxSpeed(){
		return maxSpeed;
	}
	
	public void setAvgSpeed(double avgSpeed){
		this.avgSpeed=avgSpeed;
	}
	
	public double getAvgSpeed(){
		return avgSpeed;
	}
	
	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeedSum(double sumSpeed){
		this.sumSpeed=sumSpeed;
	}
	
	public double getSpeedSum(){
		return sumSpeed;
	}
	
	public void setFare(double fare) {
		this.fare = fare;
	}

	public double getFare() {
		return fare;
	}

	public void setJournyStartLocation(Location journyStartLocation) {
		this.jornyStartLocation = journyStartLocation;
	}

	public Location getJournyStartLocation() {
		return jornyStartLocation;
	}
	public void setPrevLocation(Location prevLocation){
		this.prevLocation=prevLocation;
	}
	public Location getPrevLocation(){
		return prevLocation;
	}

	public void playSound() {
		this.setVolumeControlStream(AudioManager.STREAM_MUSIC);
		if(soundPool!=null){
			soundPool.release();
		}
		// Load the sound
		soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
		soundPool.setOnLoadCompleteListener(new OnLoadCompleteListener() {
			@Override
			public void onLoadComplete(SoundPool soundPool, int sampleId,
					int status) {
				AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
				float actualVolume = (float) audioManager
						.getStreamVolume(AudioManager.STREAM_MUSIC);
				float maxVolume = (float) audioManager
						.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
				float volume = actualVolume / maxVolume;
				// Is the sound loaded already?

				soundPool.play(soundID, volume, volume, 1, -1, 1.0f);
				soundPlayed=true;
				Log.e("Test", "Played sound");

			}
		});
		soundID = soundPool.load(this, R.raw.alarm, 1);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
//		super.onBackPressed();
	}
}
