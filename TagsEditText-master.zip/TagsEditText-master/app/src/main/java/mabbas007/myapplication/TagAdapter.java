package mabbas007.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by ryadav3 on 4/27/2017.
 */

public class TagAdapter extends BaseAdapter {
    Context context;
    ArrayList<Fruits> fruitses;
    LayoutInflater inflater;

    public TagAdapter(Context context, ArrayList<Fruits> fruitses) {
        this.context = context;
        this.fruitses = fruitses;
        inflater=LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return fruitses.size();
    }

    @Override
    public Object getItem(int i) {
        return fruitses.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if(view == null){
            view=inflater.inflate(R.layout.item_list, null);
            viewHolder=new ViewHolder(view);
            view.setTag(viewHolder);
        }else{
            viewHolder=(ViewHolder) view.getTag();
        }
        viewHolder.txtName.setText(fruitses.get(i).getName());
        viewHolder.checkBox.setChecked(fruitses.get(i).isSelected());
        return view;
    }

    class ViewHolder{
        TextView txtName;
        CheckBox checkBox;
        ViewHolder(View view){
            txtName=(TextView) view.findViewById(R.id.txtName);
            checkBox=(CheckBox) view.findViewById(R.id.checkbox);
        }
    }
}
