package mabbas007.myapplication;

import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import mabbas007.tagsedittext.TagEditText;
import mabbas007.tagsedittext.TagsEditText;

public class TagActivity extends AppCompatActivity
        implements TagEditText.TagsEditListener{

    private static final String TAG = "MainActivity";
    private TagEditText mTagsEditText;
    private ListView lstTags;
    TagAdapter tagAdapter;
    ArrayList<Fruits> fruitses=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tag);
        mTagsEditText = (TagEditText) findViewById(R.id.tagsEditText);
        lstTags=(ListView) findViewById(R.id.lstTags);
        mTagsEditText.setHint("Enter names of fruits");
        mTagsEditText.setTagsListener(this);
        mTagsEditText.setTagsWithSpacesEnabled(true);
        String[] fruits=getResources().getStringArray(R.array.fruits);
        fruitses.add(new Fruits("Does'nt Matter", false));
        for (int i=0; i<fruits.length; i++){
            Fruits fruit=new Fruits(fruits[i], false);
            fruitses.add(fruit);
        }
        tagAdapter=new TagAdapter(TagActivity.this, fruitses);
        lstTags.setAdapter(tagAdapter);
//        mTagsEditText.setThreshold(1);

        lstTags.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==0){
                    if(fruitses.get(0).isSelected()){
                        fruitses.get(0).setSelected(false);
                        mTagsEditText.removeTag(fruitses.get(0).getName());
                    }else{
                        mTagsEditText.setText(fruitses.get(0).getName());
                        fruitses.get(0).setSelected(true);
                        for (int j=1; j<fruitses.size(); j++){
                            if(fruitses.get(j).isSelected()){
                                fruitses.get(j).setSelected(false);
                                mTagsEditText.removeTag(fruitses.get(j).getName());
                            }
                        }
                    }
                }else{
                    if(fruitses.get(0).isSelected()){
                        fruitses.get(0).setSelected(false);
                        mTagsEditText.removeTag(fruitses.get(0).getName());
                    }
                    if(fruitses.get(i).isSelected()){
                        fruitses.get(i).setSelected(false);
                        mTagsEditText.removeTag(fruitses.get(i).getName());
                    }else{
                        mTagsEditText.setText(fruitses.get(i).getName());
                        fruitses.get(i).setSelected(true);
                    }
                }

                tagAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onTagAdded(String tag) {
        Log.d(TAG,"Tag Added: "+tag);
    }

    @Override
    public void onTagDeleted(String tag) {
        Log.d(TAG,"Tag Deleted: "+tag);
        for(int i=0; i< fruitses.size(); i++){
            if(tag.equals(fruitses.get(i).getName())){
                fruitses.get(i).setSelected(false);
                break;
            }
        }
        tagAdapter.notifyDataSetChanged();
    }

    @Override
    public void onEditingFinished() {
        Log.d(TAG,"OnEditing finished");
//        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
//        imm.hideSoftInputFromWindow(mTagsEditText.getWindowToken(), 0);
//        //mTagsEditText.clearFocus();
    }
}
