var greet = function() {
	console.log('Hello!');
};

module.exports = greet;