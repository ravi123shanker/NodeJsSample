var greet = require('./greet');

greet.english();
greet.spanish();