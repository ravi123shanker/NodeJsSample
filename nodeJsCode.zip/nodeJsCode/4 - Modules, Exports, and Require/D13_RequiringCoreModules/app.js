var util = require('util');

var name = 'Deepak';
var greeting = util.format('Hello, %s', name);
util.log(greeting);