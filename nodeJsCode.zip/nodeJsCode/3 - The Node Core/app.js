var a = 1;
var b = 2;
var c = a + b;

console.log(c);