var name = 'John Doe';

var greet = 'Hello ' + name;
var greet2 = `Hello ${ name }`;

console.log(greet);
console.log(greet2);