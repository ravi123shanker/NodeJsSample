module.exports = {
	events: {
		GREET: 'greet'
	}
}