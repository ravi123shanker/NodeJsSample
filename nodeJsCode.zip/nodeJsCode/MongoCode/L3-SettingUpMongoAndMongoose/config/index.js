var configValues = require('./config');

module.exports = {
    
    getDbConnectionString: function() {
        return 'YOUR_MONGO_URL';
    }
    
}