package com.example.mapdemo;

import android.app.Activity;
import android.graphics.Color;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMyLocationChangeListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

public class MainActivity extends Activity implements SensorEventListener {
	GoogleMap gMap;
	LocationManager locationManager;
	Location currentLoc = null;
	public static double lat = 23.452365;
	public static double lng = 46.786475;
	PolylineOptions pLine;

	SensorManager sensorManager;
	private Sensor sensorAccelerometer;
	private Sensor sensorMagneticField;
	private Sensor sensorRotationVector;

	private float[] valuesAccelerometer;
	private float[] valuesMagneticField;

	private float[] matrixR;
	private float[] matrixI;
	private float[] matrixValues;

	public float mDeclination = 0.0f;

	Compass myCompass;
	private final float[] mRotationMatrix = new float[16];

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

		gMap = ((MapFragment) getFragmentManager().findFragmentById(R.id.map))
				.getMap();

		myCompass = (Compass) findViewById(R.id.mycompass);

		gMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

		currentLoc = locationManager
				.getLastKnownLocation(LocationManager.GPS_PROVIDER);
		if (currentLoc == null) {
			currentLoc = locationManager
					.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
		}

		LatLng startLatLng = new LatLng(currentLoc.getLatitude(),
				currentLoc.getLongitude());
		LatLng endLatLng = new LatLng(lat, lng);

		MarkerOptions marker1 = new MarkerOptions();
		MarkerOptions marker2 = new MarkerOptions();

		marker1.position(startLatLng);
		marker2.position(endLatLng);

		LatLngBounds bounds = new LatLngBounds(new LatLng(lat, lng),
				new LatLng(currentLoc.getLatitude(), currentLoc.getLongitude()));

		gMap.addMarker(marker1);
		gMap.addMarker(marker2);

		pLine = new PolylineOptions();
		pLine.add(endLatLng);
		pLine.add(startLatLng);
		pLine.color(Color.BLUE);
		pLine.width(5);

		gMap.addPolyline(pLine);

		gMap.setMyLocationEnabled(true);

		gMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 300, 300,
				10));

		gMap.setOnMyLocationChangeListener(new OnMyLocationChangeListener() {

			@Override
			public void onMyLocationChange(Location location) {
				// TODO Auto-generated method stub
				GeomagneticField field = new GeomagneticField((float) location
						.getLatitude(), (float) location.getLongitude(),
						(float) location.getAltitude(), System
								.currentTimeMillis());

				// getDeclination returns degrees
				mDeclination = field.getDeclination();
			}
		});

		sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		sensorAccelerometer = sensorManager
				.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		sensorMagneticField = sensorManager
				.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
		sensorRotationVector = sensorManager
				.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
		valuesAccelerometer = new float[3];
		valuesMagneticField = new float[3];

		matrixR = new float[9];
		matrixI = new float[9];
		matrixValues = new float[3];
	}

	public void updateCamera(float bearing) {

		CameraPosition oldPos = gMap.getCameraPosition();

		CameraPosition pos = CameraPosition.builder(oldPos).bearing(bearing)
				.build();
		gMap.moveCamera(CameraUpdateFactory.newCameraPosition(pos));

	}


	@Override
	protected void onResume() {

		sensorManager.registerListener(this, sensorAccelerometer,
				SensorManager.SENSOR_DELAY_NORMAL);
		sensorManager.registerListener(this, sensorMagneticField,
				SensorManager.SENSOR_DELAY_NORMAL);
		sensorManager.registerListener(this, sensorRotationVector,
				SensorManager.SENSOR_DELAY_NORMAL);
		super.onResume();
	}

	@Override
	protected void onPause() {

		sensorManager.unregisterListener(this, sensorAccelerometer);
		sensorManager.unregisterListener(this, sensorMagneticField);
		sensorManager.unregisterListener(this, sensorRotationVector);
		super.onPause();
	}

	@Override
	public void onAccuracyChanged(Sensor arg0, int arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
		

		if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
			SensorManager.getRotationMatrixFromVector(mRotationMatrix,
					event.values);
			float[] orientation = new float[3];
			SensorManager.getOrientation(mRotationMatrix, orientation);
			float bearing = (float) (Math.toDegrees(orientation[0]) + mDeclination);
			
			updateCamera(bearing);
		}
	}
}
